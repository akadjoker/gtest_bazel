#pragma once
int soma(int a, int b);
